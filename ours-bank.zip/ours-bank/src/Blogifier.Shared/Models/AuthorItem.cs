﻿namespace Blogifier.Shared
{
	public class AuthorItem
	{
		public Author Author { get; set; }
		public bool Selected { get; set; }
	}
}
