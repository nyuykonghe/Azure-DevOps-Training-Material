﻿using System.Threading.Tasks;

namespace Blogifier.Admin.Pages.Profile
{
	public partial class Profile
	{

	}
}